export const ANALYTICS_CONFIG = {
  VITE_ANALYTICS_API_KEY: 'demo-api-key',
  VITE_ANALYTICS_PROJECT_ID: 'social-mastery-hub',
  VITE_ANALYTICS_USER_ID: 12345,
};
