export interface Topic {
  id: string;
  slug: string;
  title: string;
  description: string;
  icon: string;
  content: string;
}

export const topics: Topic[] = [
  { id: '1', slug: 'presenting-yourself', title: 'The Way of Presenting Yourself', icon: 'bi-person-bounding-box', description: 'Master the art of first impressions and personal branding.', content: 'Detailed content about presenting yourself...' },
  { id: '2', slug: 'effective-speaking', title: 'The Effective Way of Speaking', icon: 'bi-mic', description: 'Command attention with vocal tonality and pacing.', content: 'Detailed content about speaking...' },
  { id: '3', slug: 'attractive-stylish', title: 'The Art of Being Attractive and Stylish', icon: 'bi-stars', description: 'Elevate your physical presence and wardrobe.', content: 'Detailed content about style...' },
  { id: '4', slug: 'art-of-manipulation', title: 'The Art of Manipulation', icon: 'bi-bezier2', description: 'Understand psychological levers and influence.', content: 'Detailed content about influence...' },
  { id: '5', slug: 'communicate-effectively', title: 'How to Communicate Effectively', icon: 'bi-chat-quote', description: 'Build deep connections through active listening.', content: 'Detailed content about communication...' },
  { id: '6', slug: 'how-to-flirt', title: 'How to Flirt with Anyone', icon: 'bi-fire', description: 'The subtle dance of tension and playful banter.', content: 'Detailed content about flirting...' },
  { id: '7', slug: 'approach-anyone', title: 'How to Approach Anyone', icon: 'bi-people', description: 'Overcome approach anxiety and start conversations naturally.', content: 'Detailed content about approaching...' },
  { id: '8', slug: 'become-confident', title: 'Become a Confident Guy', icon: 'bi-lightning-charge', description: 'Build unshakeable core confidence from within.', content: 'Detailed content about confidence...' },
  { id: '9', slug: 'carrying-yourself', title: 'Art of Carrying Yourself', icon: 'bi-person-walking', description: 'Body language that projects power and ease.', content: 'Detailed content about body language...' },
  { id: '10', slug: 'successful-relationship', title: 'Make Your Relationship Successful', icon: 'bi-heart', description: 'Frameworks for long-term romantic success.', content: 'Detailed content about relationships...' },
  { id: '11', slug: 'managing-conflicts', title: 'Managing Conflicts', icon: 'bi-shield-exclamation', description: 'De-escalate and resolve interpersonal issues.', content: 'Detailed content about conflict...' },
  { id: '12', slug: 'way-of-texting', title: 'Way of Texting Anyone', icon: 'bi-phone', description: 'Digital communication that builds intrigue.', content: 'Detailed content about texting...' },
  { id: '13', slug: 'psychology-of-women', title: 'Psychology of Women', icon: 'bi-gender-female', description: 'Understand evolutionary psychology and modern dynamics.', content: 'Detailed content about female psychology...' },
  { id: '14', slug: 'human-emotions', title: 'Psychology of Human and Their Emotions', icon: 'bi-brain', description: 'Decode the emotional drivers behind human behavior.', content: 'Detailed content about emotions...' },
  { id: '15', slug: 'art-of-loving', title: 'The Art of Loving Someone', icon: 'bi-hearts', description: 'Cultivate deep, meaningful attachments.', content: 'Detailed content about love...' },
  { id: '16', slug: 'fear-of-losing-you', title: 'Create Fear of Losing You', icon: 'bi-hourglass-split', description: 'Maintain value and boundaries in relationships.', content: 'Detailed content about value...' },
  { id: '17', slug: 'perspectives-change', title: 'Perspectives That Change Everything', icon: 'bi-eye', description: 'Paradigm shifts for a better life.', content: 'Detailed content about perspectives...' },
  { id: '18', slug: 'not-boring', title: 'Art of Not Being a Boring Person', icon: 'bi-controller', description: 'Develop charisma and storytelling skills.', content: 'Detailed content about charisma...' },
];
