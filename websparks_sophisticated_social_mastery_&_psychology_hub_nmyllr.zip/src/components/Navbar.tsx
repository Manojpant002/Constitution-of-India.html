import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { topics } from '../data/topics';
import { trackInteraction } from '../lib/analyticsUsage';

export const Navbar = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isScrolled, setIsScrolled] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setSearchQuery('');
    setShowResults(false);
  }, [location]);

  const filteredTopics = topics.filter(t => 
    t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <nav id="main-navbar" className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'glass-panel py-3' : 'bg-transparent py-5'}`}>
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <Link to="/" id="nav-logo" className="text-2xl font-serif font-bold tracking-wider flex items-center gap-2">
          <i className="bi bi-infinity text-accent-green"></i>
          <span>MASTERY</span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          <div className="relative" id="search-container">
            <div className="relative">
              <i className="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
              <input
                type="text"
                placeholder="Search topics..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setShowResults(e.target.value.length > 0);
                }}
                onFocus={() => setShowResults(searchQuery.length > 0)}
                className="bg-secondary/50 border border-white/10 rounded-full py-2 pl-10 pr-4 text-sm focus:outline-none focus:border-accent-green/50 w-64 transition-all text-white placeholder-gray-500"
              />
            </div>
            
            {showResults && (
              <div className="absolute top-full mt-2 w-full glass-panel rounded-xl overflow-hidden max-h-64 overflow-y-auto">
                {filteredTopics.length > 0 ? (
                  filteredTopics.map(topic => (
                    <Link 
                      key={topic.id} 
                      to={`/topic/${topic.slug}`}
                      className="block px-4 py-3 hover:bg-white/5 border-b border-white/5 last:border-0"
                      onClick={() => trackInteraction('search_result_clicked', { topic: topic.title })}
                    >
                      <div className="text-sm font-medium text-white">{topic.title}</div>
                    </Link>
                  ))
                ) : (
                  <div className="px-4 py-3 text-sm text-gray-400">No results found</div>
                )}
              </div>
            )}
          </div>

          <Link to="/" className="text-sm font-medium text-gray-300 hover:text-white transition-colors">Home</Link>
          <Link to="/contact" className="text-sm font-medium text-gray-300 hover:text-white transition-colors">Contact</Link>
        </div>
      </div>
    </nav>
  );
};
