import React from 'react';

export const Footer = () => {
  return (
    <footer id="main-footer" className="border-t border-white/10 bg-base/80 backdrop-blur-md mt-24">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2 text-xl font-serif font-bold">
            <i className="bi bi-infinity text-accent-green"></i>
            <span>MASTERY</span>
          </div>
          
          <div className="flex gap-6">
            <a href="#" className="text-gray-400 hover:text-accent-green transition-colors"><i className="bi bi-twitter-x text-xl"></i></a>
            <a href="#" className="text-gray-400 hover:text-accent-green transition-colors"><i className="bi bi-instagram text-xl"></i></a>
            <a href="#" className="text-gray-400 hover:text-accent-green transition-colors"><i className="bi bi-youtube text-xl"></i></a>
          </div>
        </div>
        
        <div className="mt-8 text-center text-sm text-gray-500">
          &copy; {new Date().getFullYear()} Social Mastery. All rights reserved.
        </div>
      </div>
      
      <div className="w-full py-4 text-center text-xs text-gray-500 border-t border-white/5">
        Powered by <a href="https://websparks.ai" target="_blank" rel="noopener noreferrer" className="text-accent-blue hover:underline">WebSparks AI</a>
      </div>
    </footer>
  );
};
