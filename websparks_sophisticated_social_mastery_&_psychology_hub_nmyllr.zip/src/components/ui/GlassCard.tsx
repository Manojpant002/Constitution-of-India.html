import React from 'react';
import { Link } from 'react-router-dom';
import { Topic } from '../../data/topics';
import { TiltWrapper } from './TiltWrapper';

interface GlassCardProps {
  topic: Topic;
  index: number;
}

export const GlassCard: React.FC<GlassCardProps> = ({ topic, index }) => {
  return (
    <TiltWrapper id={`topic-card-wrapper-${topic.id}`}>
      <Link 
        to={`/topic/${topic.slug}`}
        id={`topic-card-${topic.id}`}
        data-visual-editor-id={`card-${topic.slug}`}
        className="block h-full"
      >
        <div className="glass-panel glass-panel-hover rounded-2xl p-6 h-full flex flex-col relative overflow-hidden group">
          {/* Subtle glow effect on hover */}
          <div className="absolute -inset-0.5 bg-gradient-to-r from-accent-green to-accent-blue opacity-0 group-hover:opacity-20 blur transition duration-500 rounded-2xl"></div>
          
          <div className="relative z-10 flex-1">
            <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center mb-4 border border-white/5 group-hover:border-accent-green/50 transition-colors">
              <i className={`bi ${topic.icon} text-2xl text-accent-green`}></i>
            </div>
            <h3 className="text-xl font-serif font-semibold mb-2 text-white group-hover:text-accent-green transition-colors">
              {topic.title}
            </h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              {topic.description}
            </p>
          </div>
          
          <div className="relative z-10 mt-6 flex items-center text-accent-blue text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity transform translate-y-2 group-hover:translate-y-0">
            Explore Module <i className="bi bi-arrow-right ml-2"></i>
          </div>
        </div>
      </Link>
    </TiltWrapper>
  );
};
