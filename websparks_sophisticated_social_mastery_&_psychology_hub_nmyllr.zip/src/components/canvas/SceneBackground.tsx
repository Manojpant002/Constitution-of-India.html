import React from 'react';
import { Canvas } from '@react-three/fiber';
import { Environment, Float, Stars } from '@react-three/drei';
import { AbstractCharacters } from './AbstractCharacters';

export const SceneBackground = () => {
  return (
    <div id="canvas-container" className="fixed inset-0 z-[-1] pointer-events-none bg-mesh-gradient">
      <Canvas shadows camera={{ position: [0, 0, 5], fov: 50 }}>
        <ambientLight intensity={0.2} />
        <directionalLight 
          position={[5, 5, 5]} 
          intensity={1} 
          castShadow 
          color="#00FF85"
        />
        <directionalLight 
          position={[-5, 5, -5]} 
          intensity={0.5} 
          color="#00E5FF"
        />
        
        <Stars radius={100} depth={50} count={3000} factor={4} saturation={0} fade speed={1} />
        
        <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
          <AbstractCharacters />
        </Float>

        <Environment preset="city" />
        
        {/* Subtle fog to blend with background */}
        <fog attach="fog" args={['#0D0D0D', 5, 15]} />
      </Canvas>
    </div>
  );
};
