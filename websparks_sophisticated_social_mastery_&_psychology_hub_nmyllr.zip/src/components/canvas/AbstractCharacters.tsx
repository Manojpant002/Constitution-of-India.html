import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useScroll } from 'framer-motion';
import * as THREE from 'three';

export const AbstractCharacters = () => {
  const boyRef = useRef<THREE.Group>(null);
  const girlRef = useRef<THREE.Group>(null);
  const { scrollYProgress } = useScroll();

  useFrame(() => {
    if (!boyRef.current || !girlRef.current) return;
    
    // Scroll logic: Boy approaches girl as user scrolls down
    const progress = scrollYProgress.get();
    
    // Boy starts at x: -4, moves to x: -1.5
    const targetBoyX = -4 + (progress * 2.5);
    boyRef.current.position.x = THREE.MathUtils.lerp(boyRef.current.position.x, targetBoyX, 0.05);
    
    // Subtle floating animation
    const time = Date.now() * 0.001;
    boyRef.current.position.y = Math.sin(time) * 0.1;
    girlRef.current.position.y = Math.cos(time) * 0.1;
  });

  return (
    <group position={[0, -1, -5]}>
      {/* Abstract Boy */}
      <group ref={boyRef} position={[-4, 0, 0]}>
        <mesh position={[0, 1.5, 0]} castShadow>
          <sphereGeometry args={[0.4, 32, 32]} />
          <meshStandardMaterial color="#00E5FF" roughness={0.2} metalness={0.8} />
        </mesh>
        <mesh position={[0, 0.5, 0]} castShadow>
          <cylinderGeometry args={[0.5, 0.3, 1.5, 32]} />
          <meshStandardMaterial color="#181818" roughness={0.5} metalness={0.5} />
        </mesh>
      </group>

      {/* Abstract Girl */}
      <group ref={girlRef} position={[2, 0, 0]}>
        <mesh position={[0, 1.4, 0]} castShadow>
          <sphereGeometry args={[0.35, 32, 32]} />
          <meshStandardMaterial color="#00FF85" roughness={0.2} metalness={0.8} />
        </mesh>
        <mesh position={[0, 0.4, 0]} castShadow>
          <coneGeometry args={[0.6, 1.6, 32]} />
          <meshStandardMaterial color="#181818" roughness={0.5} metalness={0.5} />
        </mesh>
      </group>
    </group>
  );
};
