import React, { useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { TopicDetail } from './pages/TopicDetail';
import { Contact } from './pages/Contact';
import { SceneBackground } from './components/canvas/SceneBackground';
import { initAnalyticsUser } from './lib/analyticsUsage';

function App() {
  useEffect(() => {
    initAnalyticsUser();
  }, []);

  return (
    <div className="relative min-h-screen flex flex-col">
      <SceneBackground />
      <Navbar />
      
      <main className="flex-grow relative z-10">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/topic/:slug" element={<TopicDetail />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </main>

      <Footer />
    </div>
  );
}

export default App;
