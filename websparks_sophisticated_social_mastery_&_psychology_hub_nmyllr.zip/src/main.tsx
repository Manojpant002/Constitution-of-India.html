import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import './index.css';
import 'websparks-badge';
import WebSparksAnalytics from 'websparks-analytics-sdk';
import { ANALYTICS_CONFIG } from './ownanalyticsconfig';

const analytics = new WebSparksAnalytics({
  apiKey: ANALYTICS_CONFIG.VITE_ANALYTICS_API_KEY,
  projectId: ANALYTICS_CONFIG.VITE_ANALYTICS_PROJECT_ID,
  userId: ANALYTICS_CONFIG.VITE_ANALYTICS_USER_ID,
  debug: false,
  trackSessionEnd: true,
  trackLocation: true
});

(window as any).analytics = analytics;

const handleBeforeUnload = () => {
  if ((window as any).analytics && typeof (window as any).analytics.endSession === 'function') {
    (window as any).analytics.endSession({ reason: 'browser_close' }).catch(() => {});
  }
};
window.addEventListener('beforeunload', handleBeforeUnload);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </StrictMode>,
);
