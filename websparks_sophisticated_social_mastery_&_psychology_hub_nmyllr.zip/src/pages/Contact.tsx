import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import emailjs from 'emailjs-com';
import { trackPage, trackInteraction } from '../lib/analyticsUsage';

export const Contact = () => {
  const [status, setStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');

  useEffect(() => {
    trackPage('Contact');
  }, []);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus('sending');
    
    // Note: These are placeholder EmailJS credentials. 
    // User needs to replace them with actual credentials to send to Sonupant1985@gmail.com
    emailjs.sendForm('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', e.currentTarget, 'YOUR_PUBLIC_KEY')
      .then(() => {
        setStatus('success');
        trackInteraction('form_submission', { form: 'contact', status: 'success' });
        (e.target as HTMLFormElement).reset();
      }, (error) => {
        console.error(error);
        setStatus('error');
        trackInteraction('form_submission', { form: 'contact', status: 'error' });
      });
  };

  return (
    <div id="contact-page" className="min-h-screen pt-32 pb-20 px-6 flex items-center justify-center">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass-panel rounded-3xl p-8 md:p-12 w-full max-w-2xl relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-accent-blue/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        
        <h1 className="text-4xl font-serif font-bold mb-2">Get in Touch</h1>
        <p className="text-gray-400 mb-8">Have a question or want to collaborate? Send a message.</p>
        
        <form id="contact-form" onSubmit={handleSubmit} className="space-y-6 relative z-10">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">Name</label>
            <input type="text" id="name" name="user_name" required className="w-full bg-secondary/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-accent-green transition-colors" />
          </div>
          <div>
            <label htmlFor="subject" className="block text-sm font-medium text-gray-300 mb-2">Subject</label>
            <input type="text" id="subject" name="subject" required className="w-full bg-secondary/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-accent-green transition-colors" />
          </div>
          <div>
            <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">Message</label>
            <textarea id="message" name="message" rows={5} required className="w-full bg-secondary/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-accent-green transition-colors resize-none"></textarea>
          </div>
          
          <button 
            type="submit" 
            disabled={status === 'sending'}
            className="w-full bg-accent-green text-black font-semibold py-4 rounded-xl hover:bg-white transition-colors disabled:opacity-50 flex justify-center items-center"
          >
            {status === 'sending' ? <i className="bi bi-arrow-repeat animate-spin text-xl"></i> : 'Send Message'}
          </button>
          
          {status === 'success' && <p className="text-accent-green text-center text-sm mt-4">Message sent successfully!</p>}
          {status === 'error' && <p className="text-red-400 text-center text-sm mt-4">Failed to send message. Please try again.</p>}
        </form>
      </motion.div>
    </div>
  );
};
