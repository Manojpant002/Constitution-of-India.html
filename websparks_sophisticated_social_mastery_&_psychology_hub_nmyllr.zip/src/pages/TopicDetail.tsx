import React, { useEffect } from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { topics } from '../data/topics';
import { trackPage } from '../lib/analyticsUsage';

export const TopicDetail = () => {
  const { slug } = useParams<{ slug: string }>();
  const topic = topics.find(t => t.slug === slug);

  useEffect(() => {
    if (topic) {
      trackPage(`Topic: ${topic.title}`);
      window.scrollTo(0, 0);
    }
  }, [topic]);

  if (!topic) return <Navigate to="/" />;

  return (
    <div id={`topic-page-${topic.id}`} className="min-h-screen pt-32 pb-20 px-6">
      <div className="max-w-4xl mx-auto">
        <Link to="/" className="inline-flex items-center text-accent-blue hover:text-white transition-colors mb-8 text-sm font-medium">
          <i className="bi bi-arrow-left mr-2"></i> Back to Modules
        </Link>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-panel rounded-3xl p-8 md:p-12"
        >
          <div className="w-16 h-16 rounded-2xl bg-secondary flex items-center justify-center mb-8 border border-accent-green/30 shadow-[0_0_20px_rgba(0,255,133,0.1)]">
            <i className={`bi ${topic.icon} text-3xl text-accent-green`}></i>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6 leading-tight">
            {topic.title}
          </h1>
          
          <p className="text-xl text-gray-300 mb-12 font-light leading-relaxed border-l-4 border-accent-blue pl-6">
            {topic.description}
          </p>
          
          <div className="prose prose-invert prose-lg max-w-none">
            <p className="text-gray-400 leading-relaxed mb-6">
              {topic.content}
            </p>
            <p className="text-gray-400 leading-relaxed mb-6">
              This is a placeholder for the long-form content. In a production environment, this would be populated from a CMS or database, containing detailed sub-headings, actionable advice, and psychological breakdowns.
            </p>
            <h3 className="text-2xl font-serif text-white mt-10 mb-4">Key Principles</h3>
            <ul className="list-none space-y-4 text-gray-400">
              <li className="flex items-start"><i className="bi bi-check2-circle text-accent-green mt-1 mr-3"></i> Understand the core mechanics of interaction.</li>
              <li className="flex items-start"><i className="bi bi-check2-circle text-accent-green mt-1 mr-3"></i> Apply psychological frameworks to real-world scenarios.</li>
              <li className="flex items-start"><i className="bi bi-check2-circle text-accent-green mt-1 mr-3"></i> Practice consistently to internalize the concepts.</li>
            </ul>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
