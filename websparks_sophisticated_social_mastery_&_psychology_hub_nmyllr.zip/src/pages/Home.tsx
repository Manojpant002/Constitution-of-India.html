import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { topics } from '../data/topics';
import { GlassCard } from '../components/ui/GlassCard';
import { trackPage } from '../lib/analyticsUsage';

export const Home = () => {
  useEffect(() => {
    trackPage('Home');
  }, []);

  return (
    <div id="home-page" className="min-h-screen pt-32 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Hero Section */}
        <motion.section 
          id="hero-section"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center max-w-4xl mx-auto mb-32"
        >
          <h1 className="text-5xl md:text-7xl font-serif font-bold mb-6 leading-tight">
            Transform Ideas Into <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent-green to-accent-blue text-glow">Reality</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-400 mb-10 max-w-2xl mx-auto leading-relaxed">
            Master the art of social dynamics, human psychology, and personal development. Elevate your presence and build meaningful connections.
          </p>
          <button 
            id="hero-cta"
            className="bg-accent-green text-black font-semibold px-8 py-4 rounded-full hover:bg-white hover:shadow-[0_0_30px_rgba(0,255,133,0.5)] transition-all duration-300 transform hover:-translate-y-1"
          >
            Start Your Journey <i className="bi bi-arrow-right ml-2"></i>
          </button>
        </motion.section>

        {/* Modules Grid */}
        <section id="modules-section">
          <div className="flex items-center gap-4 mb-12">
            <h2 className="text-3xl font-serif font-bold">The Modules</h2>
            <div className="h-[1px] flex-1 bg-gradient-to-r from-white/20 to-transparent"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {topics.map((topic, index) => (
              <motion.div
                key={topic.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
              >
                <GlassCard topic={topic} index={index} />
              </motion.div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
