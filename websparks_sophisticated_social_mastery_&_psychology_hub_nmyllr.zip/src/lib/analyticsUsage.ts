import { trackPageView, trackEvent, identifyUser } from '../../analytics';
import { ANALYTICS_CONFIG } from '../ownanalyticsconfig';
import { v4 as uuidv4 } from 'uuid';

const getSessionId = () => {
  let sessionId = sessionStorage.getItem('session_id');
  if (!sessionId) {
    sessionId = uuidv4();
    sessionStorage.setItem('session_id', sessionId);
  }
  return sessionId;
};

export const initAnalyticsUser = () => {
  identifyUser(getSessionId(), {
    userType: 'anonymous',
    visitTime: Date.now()
  }).catch(() => {});
};

export const trackPage = (pageName: string) => {
  trackPageView(pageName, {
    page_url: window.location.href,
    timestamp: Date.now()
  }).catch(() => {});
};

export const trackInteraction = (eventName: string, details: any) => {
  trackEvent(eventName, {
    ...details,
    page_url: window.location.href,
    timestamp: Date.now()
  }).catch(() => {});
};
